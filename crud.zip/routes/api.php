<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});
Route::any('/product/create', array('as'=>'create', 'uses'=>'ApiController@create'));
Route::any('/product/{slug?}', array('as'=>'index', 'uses'=>'ApiController@index'));
Route::any('/product/update/{id}', array('as'=>'update', 'uses'=>'ApiController@update'));
Route::any('/product/delete/{id}', array('as'=>'delete', 'uses'=>'ApiController@delete'));
