<?php

namespace App\Http\Controllers;
use App\Models\Product;
use Illuminate\Http\Request;
use Illuminate\Pagination\Paginator;
class ApiController extends Controller
{
	public function index(Request $request, $slug=null){
		$data = array();
		if($request->isMethod('get')){
			if(!empty($slug)){
				if($slug=='all'){
					$result = Product::paginate(5);
					$message = "Product listing successfully.";
				}else{
					$message = "Product load successfully.";
					$result = Product::where('id',$slug)->first();	
				}
				if($result){
					
					$data = array('success'=>true,'data'=>$result,'message'=>$message);
				}else{
					$message = "Products not found.";
					$data = array('success'=>false,'message'=>$message);
				}
			}else{
				$message = "Oops! Somthing went wrong, please try later.";
				$data = array('success'=>false,'message'=>$message);
			}
		}else{
			$message = "undefined method.";
			$data = array('success'=>false,'message'=>$message);
		}
		echo json_encode($data);
	}
	
    public function create(){
		$data = array();
		if(!empty($_POST)){
			$inputs = $_POST;
			$result = Product::create($inputs);
			if($result){
				$message = "Product add successfully.";
				$data = array('success'=>true,'message'=>$message);
			}else{
				$message = "Oops! Somthing went wrong, please try later.";
				$data = array('success'=>false,'message'=>$message);
			}			
		}else{
			$message = "Oops! Somthing went wrong, please try later.";
			$data = array('success'=>false,'message'=>$message);
		}
		echo json_encode($data);
	}
	
	public function update(Request $request, $id=null){
		if($request->isMethod('put')){
			if(!empty($request->all())){				
				$inputs = $request->all();				
				$exist = Product::find($id);
				if($exist){
					$result = $exist->update($inputs);
					$message = "Product update successfully.";
					$data = array('success'=>true,'message'=>$message);
				}else{
					$message = "Oops! Somthing went wrong, please try later.";
					$data = array('success'=>false,'message'=>$message);
				}															
			}else{
				$message = "Oops! Somthing went wrong, please try later.";
				$data = array('success'=>false,'message'=>$message);
			}
		}else{
			$message = "undefined method.";
			$data = array('success'=>false,'message'=>$message);
		}
		echo json_encode($data);
	}
	
	public function delete(Request $request, $id=null){
		if($request->isMethod('delete')){				
			$exist = Product::find($id);
			if($exist){
				$result = $exist->delete($exist);
				$message = "Product delete successfully.";
				$data = array('success'=>true,'message'=>$message);
			}else{
				$message = "Oops! Somthing went wrong, please try later.";
				$data = array('success'=>false,'message'=>$message);
			}																		
		}else{
			$message = "undefined method.";
			$data = array('success'=>false,'message'=>$message);
		}
		echo json_encode($data);
	}
}
